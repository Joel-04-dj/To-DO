package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.ArrayList;

public class TaskListAdapter extends ArrayAdapter<Task> {

    public TaskListAdapter(Context context, ArrayList<Task> tasks) {
        super(context, 0, tasks);
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        Task task = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.task_item, parent, false);
        }

        TextView tvTitle = convertView.findViewById(R.id.tvTitle);
        TextView tvDueDate = convertView.findViewById(R.id.tvDueDate);
        TextView tvCategory = convertView.findViewById(R.id.tvCategory);
        TextView tvDescription = convertView.findViewById(R.id.tvDescription);
        TextView tvPriority = convertView.findViewById(R.id.tvPriority);
        TextView tvStatus = convertView.findViewById(R.id.tvStatus);

        if (task != null) {
            tvTitle.setText(task.getTitle());
            tvDueDate.setText("Due Date: " + task.getDueDate());
            tvCategory.setText("Category: " + task.getCategory());
            tvDescription.setText("Description: " + task.getDescription());
            tvPriority.setText("Priority: " + task.getPriority());
            tvStatus.setText("Status: " + task.getStatus());
        }

        return convertView;
    }
}
