package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText editTextTask, editTextDueDate, editTextCategory, editTextDescription;
    private Spinner spinnerPriority, spinnerStatus;
    public ListView listViewTasks;
    private ArrayList<Task> taskList;
    private TaskListAdapter taskListAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextTask = findViewById(R.id.editTextTask);
        editTextDueDate = findViewById(R.id.editTextDueDate);
        editTextCategory = findViewById(R.id.editTextCategory);
        editTextDescription = findViewById(R.id.editTextDescription);
        spinnerPriority = findViewById(R.id.spinnerPriority);
        spinnerStatus = findViewById(R.id.spinnerStatus);
        Button buttonAdd = findViewById(R.id.buttonAdd);
        listViewTasks = findViewById(R.id.listViewTasks);

        taskList = new ArrayList<>();
        taskListAdapter = new TaskListAdapter(this, taskList);
        listViewTasks.setAdapter(taskListAdapter);

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addTask();
            }
        });
    }

    public void addTask() {
        String title = editTextTask.getText().toString().trim();
        String dueDate = editTextDueDate.getText().toString().trim();
        String category = editTextCategory.getText().toString().trim();
        String description = editTextDescription.getText().toString().trim();
        String priority = spinnerPriority.getSelectedItem().toString();
        String status = spinnerStatus.getSelectedItem().toString();

        if (!title.isEmpty() && !dueDate.isEmpty() && !priority.isEmpty() && !status.isEmpty()) {
            Task task = new Task(title, dueDate, category, description, priority, status);
            taskList.add(task);
            taskListAdapter.notifyDataSetChanged();

            // Clear input fields
            editTextTask.setText("");
            editTextDueDate.setText("");
            editTextCategory.setText("");
            editTextDescription.setText("");
            spinnerPriority.setSelection(0);
            spinnerStatus.setSelection(0);
        }
    }
}
