package com.example.myapplication;

public class Task {
    private final String title;
    private final String dueDate;
    private final String category;
    private final String description;
    private final String priority;
    private final String status;

    public Task(String title, String dueDate, String category, String description, String priority, String status) {
        this.title = title;
        this.dueDate = dueDate;
        this.category = category;
        this.description = description;
        this.priority = priority;
        this.status = status;
    }

    // Getter methods for each property
    public String getTitle() {
        return title;
    }

    public String getDueDate() {
        return dueDate;
    }

    public String getCategory() {
        return category;
    }

    public String getDescription() {
        return description;
    }

    public String getPriority() {
        return priority;
    }

    public String getStatus() {
        return status;
    }
}
